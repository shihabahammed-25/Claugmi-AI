# Claugmi AI — GitHub Import Project

A responsive React + TypeScript prototype for Claugmi AI, an AI data annotation and evaluation platform. This repository is reconstructed from the source material available in `Claugmi AI MVP Build (1).docx`; the document described a larger Firebase-backed codebase, but did **not** include every source file. This package therefore provides a complete, runnable frontend prototype rather than falsely claiming to contain the missing original backend implementation.

## Features

- Responsive enterprise marketing website
- Project dashboard and project list
- Create projects and search project records
- Text annotation workflow with task queue, labels, notes, and submission status
- LLM response comparison form with configurable scoring and preference
- Settings and illustrative admin overview
- Browser-local demo persistence (`localStorage`)
- Mobile/tablet responsive layouts

## Run locally

Requires Node.js 20+ (or a current supported Node version).

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm run preview
```

## Import into GitHub

1. Create a new empty repository on GitHub.
2. Extract this ZIP.
3. Upload the extracted files and folders to the repository, or use GitHub Desktop to commit and push them.
4. Keep `package.json`, `index.html`, `vite.config.ts`, `tsconfig.json`, and `src/` at the repository root.

## Important production limitations

This is a **demo frontend**, not a production-ready enterprise platform. Project/task changes are stored in the current browser only. There is no real login, Firebase backend, shared database, server-side authorization, file storage, email delivery, or secure admin permission system in this package. The “Admin demo” route is only illustrative. Do not use it for confidential customer data or production administration.

Before launch, implement and test a real backend such as Firebase Authentication + Firestore with strict security rules, organization-level data isolation, trusted server-side role checks, audit logs, file-upload security, rate limiting, and privacy/legal documentation. Do not advertise SOC 2, GDPR compliance, or other certifications until actually verified.

## Project structure

```text
claugmi-ai-platform/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── .env.example
├── .gitignore
└── src/
    ├── main.tsx
    ├── App.tsx
    └── styles.css
```
